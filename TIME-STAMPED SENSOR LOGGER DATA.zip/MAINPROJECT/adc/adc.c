#include "types.h"        // Custom data types (u32, f32)
#include <LPC21xx.h>      // LPC21xx register definitions
#include "delay.h"        // Delay functions
#include "adc_defines.h"  // ADC macro definitions (bit positions, pin configs)

/*---------------------------------------------------------
   ADC Channel Selection Array
   Maps channel numbers (0�3) to corresponding
   PINSEL1 configuration macros.
----------------------------------------------------------*/
u32 chNoSel[4] = 
{
    AIN0_PIN_0_27,   // Channel 0 ? P0.27
    AIN1_PIN_0_28,   // Channel 1 ? P0.28
    AIN2_PIN_0_29,   // Channel 2 ? P0.29
    AIN3_PIN_0_30    // Channel 3 ? P0.30
};


/*---------------------------------------------------------
   Function Name : Init_ADC
   Description   : Initializes ADC for selected channel.
                   - Configures corresponding pin as analog input
                   - Enables ADC module
                   - Sets ADC clock divider
   Parameter     : chNo ? ADC channel number (0�3)
   Return Type   : void
----------------------------------------------------------*/
void Init_ADC(u32 chNo)
{
    /* Clear previous pin configuration (P0.27�P0.30) */
    PINSEL1 &= ~(chNoSel[chNo]);

    /* Configure selected pin as ADC input */
    PINSEL1 |= chNoSel[chNo];

    /* Configure ADC Control Register (ADCR):
       - PDN_BIT ? Power up ADC
       - CLKDIV  ? Set ADC clock */
    ADCR |= (1 << PDN_BIT) | (CLKDIV << CLKDIV_BITS);
}


/*---------------------------------------------------------
   Function Name : Read_ADC
   Description   : Reads analog input from selected ADC channel.
                   Returns:
                   - Digital ADC value (0�1023)
                   - Equivalent analog voltage
   Parameters    :
        chNo    ? ADC channel number (0�3)
        eAR     ? Pointer to store equivalent analog voltage
        adcDVal ? Pointer to store digital ADC value
   Return Type   : void
----------------------------------------------------------*/
void Read_ADC(u32 chNo, f32 *eAR, u32 *adcDVal)
{
    /* Clear previous channel selection */
    ADCR &= 0xFFFFFF00;

    /* Select required channel and start conversion */
    ADCR |= ((1 << ADC_CONV_START_BIT) | (1 << chNo));

    /* Small delay for conversion */
    delay_us(3);

    /* Wait until conversion is completed (DONE bit = 1) */
    while(((ADDR >> DONE_BIT) & 1) == 0);

    /* Stop ADC conversion */
    ADCR &= ~(1 << ADC_CONV_START_BIT);

    /* Read 10-bit digital result */
    *adcDVal = ((ADDR >> DIGITAL_DATA_BITS) & 1023);

    /* Convert digital value to analog voltage
       Assuming:
       - 10-bit ADC (0�1023)
       - Reference voltage = 3.3V */
}
