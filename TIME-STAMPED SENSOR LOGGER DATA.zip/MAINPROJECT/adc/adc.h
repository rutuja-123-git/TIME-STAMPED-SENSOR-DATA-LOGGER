#include "types.h"   // Custom data types (u32, f32)

/*---------------------------------------------------------
   ADC Function Prototypes
   Description : Declarations of ADC driver functions
----------------------------------------------------------*/

/*---------------------------------------------------------
   Function Name : Init_ADC
   Description   : Initializes ADC module for the selected
                   channel (0�3).
                   Configures corresponding pin as analog input
                   and enables ADC hardware.
   Parameter     : chNo ? ADC channel number (0�3)
   Return Type   : void
----------------------------------------------------------*/
void Init_ADC(u32 chNo);


/*---------------------------------------------------------
   Function Name : Read_ADC
   Description   : Reads analog value from selected ADC channel.
                   Provides:
                   - Digital ADC value (0�1023 for 10-bit ADC)
                   - Equivalent analog voltage
   Parameters    :
        chNo     ? ADC channel number (0�3)
        eAR      ? Pointer to store equivalent analog voltage
        adcDVal  ? Pointer to store digital ADC value
   Return Type   : void
----------------------------------------------------------*/
void Read_ADC(u32 chNo, f32 *eAR, u32 *adcDVal);
