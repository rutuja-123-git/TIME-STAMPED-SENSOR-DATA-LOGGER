/* Main Oscillator Frequency = 12 MHz crystal */
#define FOSC 12000000

/* CPU Clock (CCLK) = 5 � FOSC = 60 MHz */
#define CCLK (FOSC * 5)

/* Peripheral Clock (PCLK) = CCLK / 4 = 15 MHz */
#define PCLK (CCLK / 4)

/* Required ADC Clock (Maximum recommended � 3 MHz) */
#define ADCCLK 3000000

/* Clock Divider value for ADC
   Formula: (PCLK / ADCCLK) - 1
   Used to generate proper ADC operating frequency */
#define CLKDIV ((PCLK / ADCCLK) - 1)



/*---------------------------------------------------------
   Definitions for ADCR (ADC Control Register)
----------------------------------------------------------*/

/* CLKDIV bits position (Bits 8�15)
   Used to set ADC clock divider */
#define CLKDIV_BITS        8   //@8-15

/* PDN bit position (Bit 21)
   Power Down bit
   1 = ADC operational
   0 = ADC powered down */
#define PDN_BIT            21

/* ADC Start Conversion bit (Bit 24)
   Used to start ADC conversion */
#define ADC_CONV_START_BIT 24



/*---------------------------------------------------------
   Definitions for ADDR (ADC Data Register)
----------------------------------------------------------*/

/* Digital Data bit position (Bits 6�15)
   Stores 10-bit ADC result */
#define DIGITAL_DATA_BITS 6   //@6-15

/* DONE bit position (Bit 31)
   1 = Conversion complete
   0 = Conversion in progress */
#define DONE_BIT          31



/*---------------------------------------------------------
   PINSEL1 Configuration for ADC Channels
----------------------------------------------------------*/

/* Configure P0.27 as AIN0 */
#define AIN0_PIN_0_27 0x00400000

/* Configure P0.28 as AIN1 */
#define AIN1_PIN_0_28 0x01000000

/* Configure P0.29 as AIN2 */
#define AIN2_PIN_0_29 0x04000000

/* Configure P0.30 as AIN3 */
#define AIN3_PIN_0_30 0x10000000



/*---------------------------------------------------------
   ADC Channel Numbers
----------------------------------------------------------*/

/* ADC Channel 0 */
#define CH0 0

/* ADC Channel 1 */
#define CH1 1

/* ADC Channel 2 */
#define CH2 2

/* ADC Channel 3 */
#define CH3 3


