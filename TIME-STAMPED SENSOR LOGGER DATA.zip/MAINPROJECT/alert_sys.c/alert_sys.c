#include "types.h"      // Custom data types (u8, s32, etc.)
#include "lpc21xx.h"    // LPC21xx register definitions
#include "uart.h"       // UART communication functions
#include "rtc.h"        // RTC functions

/* GPIO Pin Definitions */
#define ALERT_PIN    16     // Alert output connected to P0.16
#define LED_PIN      17     // LED indicator connected to P0.17

/* External temperature set point (defined in main module) */
extern s32 set_point;


/*---------------------------------------------------------
   Function Name : temp_alert
   Description   : Checks if temperature exceeds set point.
                   If exceeded:
                       - Turns ON LED and ALERT pin
                       - Sends alert message with timestamp via UART
                   Else:
                       - Turns OFF LED and ALERT pin
   Parameter     : temperature -> Current temperature value
   Return Type   : void
----------------------------------------------------------*/
void temp_alert(s32 temperature)
{
    /* Variables to store current RTC values */
    s32 hour, min, sec;
    s32 date, month, year;
    s32 day;

    /* Configure LED and ALERT pins as output
       (Ideally this should be done once in main) */
    IODIR0 |= (1<<LED_PIN) | (1<<ALERT_PIN);

    /* Get current time and date from RTC */
    GetRTCTimeInfo(&hour, &min, &sec);
    GetRTCDateInfo(&date, &month, &year);
    GetRTCDay(&day);

    /* Check if temperature exceeds threshold */
    if (temperature > set_point)
    {
        /* Turn ON LED and ALERT output */
        IOSET0 = (1<<LED_PIN) | (1<<ALERT_PIN);

        /* Send alert message via UART */
        UARTTxStr("[ALERT] Over Temperature: ");
        UARTTxu32(temperature);
        UARTTxStr("C @ ");

        /* Print Time (HH:MM:SS) with leading zeros */
        if (hour < 10)
            UARTTxChar('0');
        UARTTxu32(hour);
        UARTTxChar(':');

        if (min < 10)
            UARTTxChar('0');
        UARTTxu32(min);
        UARTTxChar(':');

        if (sec < 10)
            UARTTxChar('0');
        UARTTxu32(sec);
        UARTTxStr(" ");

        /* Print Date (DD/MM/YYYY) with leading zeros */
        if (date < 10)
            UARTTxChar('0');
        UARTTxu32(date);
        UARTTxChar('/');

        if (month < 10)
            UARTTxChar('0');
        UARTTxu32(month);
        UARTTxChar('/');

        UARTTxu32(year);

        UARTTxStr("\r\n");   // New line after alert message
    }
    else
    {
        /* Turn OFF LED and ALERT output */
        IOCLR0 = (1<<LED_PIN) | (1<<ALERT_PIN);
    }
}
