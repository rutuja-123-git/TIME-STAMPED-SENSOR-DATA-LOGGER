/*---------------------------------------------------------
   Function Name : temp_alert
   Description   : This function is used to generate
                   a temperature alert based on the
                   measured temperature value.

   Parameter     : temperature
                   ? Signed 32-bit integer (s32)
                   ? Contains temperature value

   Return Type   : void
                   ? Does not return any value
----------------------------------------------------------*/
void temp_alert(s32 temperature);
