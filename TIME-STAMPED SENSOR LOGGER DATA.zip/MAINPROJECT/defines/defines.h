/*---------------------------------------------------------
   Bit Manipulation Macros
   Used for register-level programming in embedded systems
----------------------------------------------------------*/

/* Set a particular bit (BP = Bit Position)
   Makes the specified bit = 1 */
#define SETBIT(WORD,BP) WORD |= 1 << BP


/* Clear a particular bit
   Makes the specified bit = 0 */
#define CLRBIT(WORD,BP) WORD &= ~(1 << BP)


/* Complement (Toggle) a particular bit
   1 ? 0
   0 ? 1 */
#define CPLBIT(WORD,BP) WORD ^= (1 << BP)


/* Write a specific value (0 or 1) to a bit position
   BIT should be 0 or 1 */
#define WRITEBIT(WORD,BP,BIT) \
        WORD = ((WORD & ~(1 << BP)) | (BIT << BP))


/* Write 4-bit value (Nibble) starting from SBP (Start Bit Position)
   Used when configuring 4-bit fields in registers */
#define WRITENIBBLE(WORD,SBP,NIBBLE) \
        WORD = ((WORD & ~(0xF << SBP)) | (NIBBLE << SBP))


/* Write 8-bit value (Byte) starting from SBP */
#define WRITEBYTE(WORD,SBP,BYTE) \
        WORD = ((WORD & ~(0xFF << SBP)) | (BYTE << SBP))


/* Write 16-bit value (Half Word) starting from SBP */
#define WRITEHWORD(WORD,SBP,HWORD) \
        WORD = ((WORD & ~(0xFFFF << SBP)) | (HWORD << SBP))


/* Read a specific bit
   Returns 0 or 1 */
#define READBIT(WORD,BITPOS) ((WORD >> BITPOS) & 1)
