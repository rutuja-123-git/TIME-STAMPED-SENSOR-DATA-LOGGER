#include "display.h"   // Display function declarations
#include "lcd.h"       // LCD interface functions
#include "uart.h"      // UART communication functions
#include "rtc.h"       // RTC functions
#include "delay.h"     // Delay utilities

/* External variable (defined in main file) */
extern s32 set_point;   // Temperature set point (used for reference)

/* Weekday names (3-letter format) */
static char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};

/* ---------------------------------------------------------
   Function Name  : Display_Data
   Description    : Displays current time, date, and 
                    temperature on LCD.
                    Sends temperature log via UART 
                    once every minute.
   Input          : temp -> Current temperature value
   Output         : None
----------------------------------------------------------*/
void Display_Data(s32 temp)
{
    /* Variables to store RTC values */
    s32 hour, min, sec;
    s32 date, month, year;
    s32 day;

    /* Static variable to track previous minute 
       (used to log data once per minute) */
    static s32 prev_min = -1;

    /* -------- Read Current RTC Time & Date -------- */
    GetRTCTimeInfo(&hour, &min, &sec);     // Get current time
    GetRTCDateInfo(&date, &month, &year);  // Get current date
    GetRTCDay(&day);                       // Get current weekday

    /* -------- Clear LCD Screen -------- */
    CmdLCD(0x01);     // Clear display command

    /* -------- Display Time (HH:MM:SS DAY) -------- */
    CmdLCD(0x80);     // Move cursor to first row

    CharLCD((hour / 10) + '0');   // Tens digit of hour
    CharLCD((hour % 10) + '0');   // Units digit of hour
    CharLCD(':');

    CharLCD((min / 10) + '0');    // Tens digit of minute
    CharLCD((min % 10) + '0');    // Units digit of minute
    CharLCD(':');

    CharLCD((sec / 10) + '0');    // Tens digit of second
    CharLCD((sec % 10) + '0');    // Units digit of second
    CharLCD(' ');

    StrLCD(week[day]);            // Display weekday (SUN�SAT)

    /* -------- Display Date & Temperature -------- */
    CmdLCD(0xC0);     // Move cursor to second row

    /* Display Date (DD/MM/YY) */
    CharLCD((date / 10) + '0');
    CharLCD((date % 10) + '0');
    CharLCD('/');

    CharLCD((month / 10) + '0');
    CharLCD((month % 10) + '0');
    CharLCD('/');

    CharLCD((year % 100) / 10 + '0');   // Tens digit of year
    CharLCD((year % 100) % 10 + '0');   // Units digit of year
    CharLCD(' ');

    /* Display Temperature */
    CharLCD('T');
    CharLCD(':');
    IntLCD(temp);          // Display integer temperature value
    CharLCD(0xDF);         // Degree symbol (�)
    CharLCD('C');          // Celsius unit

    /* Delay 1 second before refreshing display */
    delay_ms(1000);

    /* -------- UART Logging (Once Per Minute) -------- */
    if(min != prev_min)   // Check if minute has changed
    {
        prev_min = min;   // Update previous minute

        UARTTxStr("TEMP:");
        UARTTxu32(temp);
        UARTTxStr("C ");

        UARTTxStr("TIME:");
        UARTTxu32(hour);
        UARTTxChar(':');
        UARTTxu32(min);
        UARTTxChar(':');
        UARTTxu32(sec);

        UARTTxStr(" DATE:");
        UARTTxu32(date);
        UARTTxChar('/');
        UARTTxu32(month);
        UARTTxChar('/');
        UARTTxu32(year);

        UARTTxStr("\r\n");   // New line for next log entry
    }
}
