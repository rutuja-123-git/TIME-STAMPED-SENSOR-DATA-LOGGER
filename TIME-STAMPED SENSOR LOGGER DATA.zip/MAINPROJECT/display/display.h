#include "types.h"   // Custom data type definitions (s32)

/*---------------------------------------------------------
   Function Name : Display_Data
   Description   : Displays current time, date, and 
                   temperature on LCD.
                   Also sends time-stamped temperature
                   data through UART.
   Parameter     : temp ? Current temperature value
   Return Type   : void
----------------------------------------------------------*/
void Display_Data(s32 temp);
