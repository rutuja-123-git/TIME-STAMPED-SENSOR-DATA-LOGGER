#include <lpc21xx.h>     // LPC21xx register definitions
#include "types.h"       // Custom data types (u8, s32, etc.)
#include "lcd.h"         // LCD interface functions
#include "keypad.h"      // Keypad functions
#include "rtc.h"         // RTC register access
#include "uart.h"        // UART communication
#include "delay.h"       // Delay functions
#include "editmode.h"    // Edit mode header
#include "defines.h"     // Macro definitions

/* Switch connected to P0.16 */
#define SWITCH_PIN  16

/* External global variables (declared in main file) */
extern s32 set_point;   // Temperature threshold value
extern u8  edit_flag;   // Edit mode status flag

/* Global variables */
u8 choice;              // Stores keypad choice
s32 temp,d,m,y,flg=0;   // General purpose variables

/* -------- Static Function Prototypes -------- */
static void edit_rtc(void);          // Edit RTC parameters
static void edit_set_point(void);    // Edit temperature set point
static int set_multi(u8 *str);       // Multi-digit input function


/*---------------------------------------------------------
   Function Name : edit_mode
   Description   : Checks switch press and enables edit menu.
                   Allows user to edit RTC, set temperature,
                   or exit edit mode.
----------------------------------------------------------*/
void edit_mode(void)
{
    /* Check if switch is pressed */
    if((IOPIN0>>SWITCH_PIN)&1)
    {
        /* Wait while switch is active */
        while((READBIT(IOPIN0,SWITCH_PIN)) == 0)
        {
            /* Display edit menu */
            CmdLCD(0x01);
            CmdLCD(0x80);
            StrLCD("1.EDIT RTC");

            CmdLCD(0xc0);
            StrLCD("2.E.ST 3.EX");

            /* Scan keypad */
            WRITENIBBLE(IOPIN1 , 24, 0x0);
            while(ColStat());
            choice = KeyVal();

            /* Perform action based on key pressed */
            switch(choice)
            {
                case '1' :
                    edit_rtc();          // Edit RTC settings
                    break;

                case '2' :
                    edit_set_point();    // Edit temperature set point
                    break;

                case '3' :
                    CmdLCD(0x01);
                    StrLCD("EXITING...");
                    delay_ms(800);
                    edit_flag = 0;
                    UARTTxStr("* EXIT EDIT MODE *\r\n");
                    return;              // Exit edit mode
            }
        }
    }
}


/*---------------------------------------------------------
   Function Name : set_multi
   Description   : Accepts multi-digit numeric input
                   from keypad.
                   '*' -> Confirm input
                   '#' -> Backspace
   Parameter     : str -> Prompt message to display
   Return        : Entered integer value
----------------------------------------------------------*/
static int set_multi(u8 *str)
{
    u32 Value1=0, Value2=0, i;

    while(1)
    {
        WRITENIBBLE(IOPIN1 ,24, 0x0);

        /* Display prompt */
        CmdLCD(0x80);
        for(i = 0 ; i < str[i] ; i++)
            CharLCD(str[i]);

        while(ColStat());
        Value1 = KeyVal();

        if(Value1 == '*')       // Confirm entry
        {
            return Value2;
        }
        else if(Value1 == '#')  // Delete last digit
        {
            Value2 = Value2 / 10;
            CmdLCD(0x01);
            CmdLCD(0xc0);
            IntLCD(Value2);
        }
        else                    // Add new digit
        {
            if(Value2 < 9999)   // Limit input size
            {
                Value2 = Value2 * 10 + (Value1 - '0');
                CmdLCD(0xc0);
                IntLCD(Value2);
            }
        }
    }
}


/*---------------------------------------------------------
   Function Name : edit_rtc
   Description   : Allows user to edit RTC parameters:
                   Hour, Minute, Second, Day, Date,
                   Month, Year.
----------------------------------------------------------*/
static void edit_rtc(void)
{
    s32 value;

    while (1)
    {
        /* Display RTC edit menu */
        CmdLCD(0x01);
        CmdLCD(0x80);
        StrLCD("1H 2M 3S 4D");
        CmdLCD(0xC0);
        StrLCD("5DT 6MN 7YR 8E");

        WRITENIBBLE(IOPIN1 ,24, 0x0);
        while(ColStat());
        choice = KeyVal();

        switch (choice)
        {
            case '1':   // Set Hour
                CmdLCD(0x01);
                value = set_multi("SET HOUR(0-23)");
                if (value <= 23)
                    HOUR = value;
                break;

            case '2':   // Set Minute
                CmdLCD(0x01);
                value = set_multi("SET MIN(0-59)");
                if (value <= 59)
                    MIN = value;
                break;

            case '3':   // Set Second
                CmdLCD(0x01);
                value = set_multi("SET SEC(0-59)");
                if (value <= 59)
                    SEC = value;
                break;

            case '4':   // Set Day of Week
                CmdLCD(0x01);
                value = set_multi("SET DAY(0-6)");
                if (value <= 6)
                    DOW = value;
                break;

            case '5':   // Set Date
                CmdLCD(0x01);
                value = set_multi("SET DATE(1-31)");
                if (value >= 1 && value <= 31)
                    DOM = value;
                break;

            case '6':   // Set Month
                CmdLCD(0x01);
                value = set_multi("SET MONTH(1-12)");
                if (value >= 1 && value <= 12)
                    MONTH = value;
                break;

            case '7':   // Set Year
                CmdLCD(0x01);
                value = set_multi("SET YEAR");
                if (value <= 4095)
                    YEAR = value;
                break;

            case '8':   // Exit RTC Edit
                CmdLCD(0x01);
                StrLCD("RTC UPDATED");
                delay_ms(800);
                return;
        }
    }
}


/*---------------------------------------------------------
   Function Name : edit_set_point
   Description   : Allows user to change temperature
                   threshold (20�C to 80�C).
----------------------------------------------------------*/
static void edit_set_point(void)
{
    s32 value;

    CmdLCD(0x01);

    value = set_multi("SET TEMP(20-80)");

    if (value >= 20 && value <= 80)
    {
        set_point = value;      // Update set point
        CmdLCD(0x01);
        StrLCD("SETPOINT OK");
    }
    else
    {
        CmdLCD(0x01);
        StrLCD("INVALID VALUE");
    }

    delay_ms(800);
}
