/*---------------------------------------------------------
   Function Name : edit_mode
   Description   : Enables and handles edit mode operation.
                   Used to modify parameters such as 
                   temperature set point using keypad input.
   Parameter     : None
   Return Type   : void
----------------------------------------------------------*/
void edit_mode(void);


