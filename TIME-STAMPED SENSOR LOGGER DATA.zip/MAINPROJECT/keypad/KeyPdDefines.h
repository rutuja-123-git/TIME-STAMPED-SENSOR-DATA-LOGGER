#include <LPC21xx.h>   // LPC21xx register definitions
#include "types.h"     // Custom data types (u8)

/*---------------------------------------------------------
   4x4 Matrix Keypad Pin Configuration
   Rows  ? P1.24 to P1.27
   Columns ? P1.28 to P1.31
----------------------------------------------------------*/

/* Row Pins */
#define R0 24   // Row 0 connected to P1.24
#define R1 25   // Row 1 connected to P1.25
#define R2 26   // Row 2 connected to P1.26
#define R3 27   // Row 3 connected to P1.27

/* Column Pins */
#define C0 28   // Column 0 connected to P1.28
#define C1 29   // Column 1 connected to P1.29
#define C2 30   // Column 2 connected to P1.30
#define C3 31   // Column 3 connected to P1.31


/*---------------------------------------------------------
   Lookup Table (LUT) for 4x4 Keypad
   Description :
   Maps row and column intersection to corresponding key.
   
   Keypad Layout:
       C0   C1   C2   C3
   R0  '1'  '2'  '3'  'A'
   R1  '4'  '5'  '6'  'B'
   R2  '7'  '8'  '9'  'C'
   R3  '*'  '0'  '#'  'D'
----------------------------------------------------------*/
u8 LUT[][4] = 
{
    {'1','2','3','A'},
    {'4','5','6','B'},
    {'7','8','9','C'},
    {'*','0','#','D'}
};

