#include <LPC21xx.h>     // LPC21xx register definitions
#include "delay.h"       // Delay functions
#include "lcd.h"         // LCD function declarations
#include "types.h"       // Custom data types (u8, s32, f32)
#include "defines.h"     // Macro definitions

/*---------------------------------------------------------
   LCD Pin Configuration
   Data Pins  : P1.16 � P1.23  (8-bit mode)
   Control Pins:
        RS -> P0.11  (Register Select)
        RW -> P0.12  (Read/Write)
        EN -> P0.13  (Enable)
----------------------------------------------------------*/
#define LCD_DAT (0xFF << 16)   // LCD data lines mask (P1.16�P1.23)
#define RS 11                  // Register Select pin
#define RW 12                  // Read/Write pin
#define EN 13                  // Enable pin


/*---------------------------------------------------------
   Function Name : InitLCD
   Description   : Initializes LCD in 8-bit mode.
                   Configures:
                   - 2-line display
                   - 5x7 font
                   - Cursor OFF
                   - Display ON
----------------------------------------------------------*/
void InitLCD(void)
{
    IODIR1 |= LCD_DAT;    // Set P1.16�P1.23 as output (data lines)
    IODIR0 |= (1 << RS) | (1 << RW) | (1 << EN); // Control pins as output

    delay_ms(10);         // Initial power-on delay

    /* LCD initialization sequence */
    CmdLCD(0x30);
    delay_ms(1);
    CmdLCD(0x30);
    delay_ms(1);
    CmdLCD(0x38);         // 8-bit mode, 2 lines

    CmdLCD(0x38);         // Function set
    CmdLCD(0x10);         // Display OFF
    CmdLCD(0x01);         // Clear display
    CmdLCD(0x06);         // Entry mode (cursor increment)
    CmdLCD(0x0C);         // Display ON, cursor OFF
}


/*---------------------------------------------------------
   Function Name : CmdLCD
   Description   : Sends command to LCD.
                   RS = 0 ? Command mode
----------------------------------------------------------*/
void CmdLCD(u8 cmd)
{
    IOCLR0 = (1 << RS);   // RS = 0 (Command)
    DispLCD(cmd);         // Send command
}


/*---------------------------------------------------------
   Function Name : CharLCD
   Description   : Sends single character to LCD.
                   RS = 1 ? Data mode
----------------------------------------------------------*/
void CharLCD(u8 dat)
{
    IOSET0 = (1 << RS);   // RS = 1 (Data)
    DispLCD(dat);         // Send character
}


/*---------------------------------------------------------
   Function Name : DispLCD
   Description   : Low-level function to send data/command
                   to LCD.
----------------------------------------------------------*/
void DispLCD(u8 val)
{
    IOCLR0 = (1 << RW);        // RW = 0 (Write operation)

    IOCLR1 = LCD_DAT;          // Clear previous data
    IOSET1 = ((u32)val << 16); // Place new data on P1.16�P1.23

    IOSET0 = (1 << EN);        // Enable = 1
    delay_ms(1);
    IOCLR0 = (1 << EN);        // Enable = 0 (Latch data)
    delay_ms(2);
}


/*---------------------------------------------------------
   Function Name : StrLCD
   Description   : Displays null-terminated string on LCD.
----------------------------------------------------------*/
void StrLCD(char *ptr)
{
    while (*ptr)
        CharLCD(*ptr++);   // Send each character
}


/*---------------------------------------------------------
   Function Name : IntLCD
   Description   : Displays signed integer on LCD.
----------------------------------------------------------*/
void IntLCD(s32 num)
{
    u8 buf[10];
    s8 i = 0;

    if (num == 0)
    {
        CharLCD('0');
        return;
    }

    if (num < 0)
    {
        CharLCD('-');
        num = -num;
    }

    /* Convert integer to ASCII (reverse order) */
    while (num)
    {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }

    /* Display digits in correct order */
    while (--i >= 0)
        CharLCD(buf[i]);
}


/*---------------------------------------------------------
   Function Name : FltLCD
   Description   : Displays floating-point value on LCD.
                   Shows 2 digits after decimal point.
----------------------------------------------------------*/
void FltLCD(f32 val)
{
    s32 ip;      // Integer part
    f32 fp;      // Fractional part
    u8 i, d;

    if (val < 0)
    {
        CharLCD('-');
        val = -val;
    }

    ip = (s32)val;
    IntLCD(ip);       // Display integer part

    CharLCD('.');

    fp = val - ip;    // Get fractional part

    /* Display 2 decimal digits */
    for (i = 0; i < 2; i++)
    {
        fp *= 10;
        d = (u8)fp;
        CharLCD(d + '0');
        fp -= d;
    }
}


/*---------------------------------------------------------
   Function Name : StoreCustCharFont
   Description   : Stores custom character in LCD CGRAM.
                   Example: Custom symbol pattern.
----------------------------------------------------------*/
void StoreCustCharFont(void)
{
    u8 i;

    /* Custom character pattern (8 bytes) */
    u8 LUT[8] = {0x00,0x00,0x04,0x0C,0x1C,0x1C,0x1C,0x00};

    CmdLCD(0x40);   // Set CGRAM address

    for (i = 0; i < 8; i++)
        CharLCD(LUT[i]);

    CmdLCD(0x80);   // Return to DDRAM
}

