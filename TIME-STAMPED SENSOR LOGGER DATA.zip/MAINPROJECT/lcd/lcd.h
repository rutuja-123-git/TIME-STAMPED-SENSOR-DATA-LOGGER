#include "types.h"   // Custom data types (u8, s32, f32)

/*---------------------------------------------------------
   LCD Function Prototypes
   Description : Declarations of LCD driver functions
----------------------------------------------------------*/

/*---------------------------------------------------------
   Function Name : InitLCD
   Description   : Initializes LCD in 8-bit mode.
                   Configures display settings.
   Parameter     : None
   Return Type   : void
----------------------------------------------------------*/
void InitLCD(void);


/*---------------------------------------------------------
   Function Name : CmdLCD
   Description   : Sends a command to LCD.
                   (RS = 0 ? Command mode)
   Parameter     : u8 ? Command byte
   Return Type   : void
----------------------------------------------------------*/
void CmdLCD(u8);


/*---------------------------------------------------------
   Function Name : CharLCD
   Description   : Displays a single character on LCD.
                   (RS = 1 ? Data mode)
   Parameter     : u8 ? Character to display
   Return Type   : void
----------------------------------------------------------*/
void CharLCD(u8);


/*---------------------------------------------------------
   Function Name : DispLCD
   Description   : Low-level function to send data/command
                   to LCD (handles EN, RW signals).
   Parameter     : u8 ? Data/command byte
   Return Type   : void
----------------------------------------------------------*/
void DispLCD(u8);


/*---------------------------------------------------------
   Function Name : StrLCD
   Description   : Displays a null-terminated string on LCD.
   Parameter     : char* ? Pointer to string
   Return Type   : void
----------------------------------------------------------*/
void StrLCD(char *);


/*---------------------------------------------------------
   Function Name : IntLCD
   Description   : Displays signed integer value on LCD.
   Parameter     : s32 ? Integer number
   Return Type   : void
----------------------------------------------------------*/
void IntLCD(s32);


/*---------------------------------------------------------
   Function Name : FltLCD
   Description   : Displays floating-point number on LCD.
   Parameter     : f32 ? Floating-point value
   Return Type   : void
----------------------------------------------------------*/
void FltLCD(f32);


/*---------------------------------------------------------
   Function Name : StoreCustCharFont
   Description   : Stores a custom character pattern
                   into LCD CGRAM.
   Parameter     : None
   Return Type   : void
----------------------------------------------------------*/
void StoreCustCharFont(void);
