#include "types.h"        // Custom data types (u8, u32, f32)
#include "adc.h"          // ADC driver functions
#include "adc_defines.h"  // ADC channel definitions (CH0, CH1, etc.)

/*---------------------------------------------------------
   Function Name : Read_LM35
   Description   : Reads analog voltage from LM35 sensor
                   using ADC and converts it into temperature.

                   LM35 Characteristics:
                   - Output voltage = 10mV per �C
                   - 0�C  ? 0.00V
                   - 25�C ? 0.25V
                   - 100�C ? 1.00V

                   Temperature calculation:
                   Temperature (�C) = Voltage � 100

   Parameter     : tType
                   'C' ? Return temperature in Celsius
                   'F' ? Return temperature in Fahrenheit

   Return Type   : f32 ? Temperature value
----------------------------------------------------------*/
f32 Read_LM35(u8 tType)
{
    u32 adcDVal;   // Stores raw ADC digital value
    f32 eAR;       // Stores equivalent analog voltage (ADC result)
    f32 tDeg;      // Stores calculated temperature

    /* Read ADC from Channel 1
       eAR     ? Analog voltage
       adcDVal ? Digital ADC value */
    Read_ADC(CH1, &eAR, &adcDVal);

    /* Convert voltage to temperature in Celsius
       LM35 gives 10mV per �C
       So Temperature = Voltage � 100 */
    tDeg = eAR * 100.0f;

    /* Convert to Fahrenheit if requested */
    if(tType == 'F')
    {
        tDeg = (tDeg * 9.0f / 5.0f) + 32.0f;
    }

    return tDeg;   // Return temperature
}
