#include "types.h"   // Custom data type definitions (u8, f32)

/*---------------------------------------------------------
   Function Name : Read_LM35
   Description   : Reads temperature value from LM35 sensor
                   using ADC and converts it into required
                   temperature unit.
   Parameter     : tType 
                   'C' ? Returns temperature in Celsius
                   'F' ? Returns temperature in Fahrenheit
   Return Type   : f32 ? Temperature value (floating point)
----------------------------------------------------------*/
f32 Read_LM35(u8 tType);

