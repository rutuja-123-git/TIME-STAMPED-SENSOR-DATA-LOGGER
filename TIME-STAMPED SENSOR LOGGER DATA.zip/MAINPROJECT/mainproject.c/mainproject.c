#include <LPC21xx.h>      // LPC21xx Register Definitions
#include "types.h"        // Custom data types (u8, s32, etc.)
#include "rtc.h"          // Real Time Clock functions
#include "lcd.h"          // LCD interface functions
#include "uart.h"         // UART communication functions
#include "delay.h"        // Delay utilities
#include "keypad.h"       // Keypad interface
#include "editmode.h"     // Edit mode handling
#include "lm35.h"         // LM35 temperature sensor functions
#include "display.h"      // Display formatting functions
#include "adc.h"          // ADC driver functions
#include "adc_defines.h"  // ADC configuration macros
#include "defines.h"      // General macro definitions
#include "alert_sys.h"    // Alert system functions

/* ------------------- Pin Definitions ------------------- */
#define SWITCH_PIN   (1<<16)   // Switch connected to P0.16
#define ALERT_PIN    15        // Alert output connected to P0.15
#define LED_PIN      17        // LED output connected to P0.17

/* ------------------- Global Variables ------------------- */
s32 set_point = 45;   // Default temperature threshold (45�C)
u8  edit_flag = 0;    // Flag to indicate edit mode status

/* ------------------- Main Function ------------------- */
int main(void)
{
    s32 temperature;   // Variable to store temperature value

    /* -------- Peripheral Initialization -------- */
    InitUART();        // Initialize UART for serial communication
    InitLCD();         // Initialize LCD display
    RTC_Init();        // Initialize Real Time Clock
    Init_ADC(CH1);     // Initialize ADC Channel 1 for LM35
    KeyPdInit();       // Initialize Keypad

    /* -------- Set Initial RTC Time & Date -------- */
    SetRTCTimeInfo(05,40,02);   // Set Time: HH, MM, SS
    SetRTCDateInfo(04,02,26);   // Set Date: DD, MM, YY

    /* -------- Configure GPIO Pins -------- */
    IODIR0 |= (1 << ALERT_PIN) | (1 << LED_PIN);  
    // Configure ALERT and LED pins as OUTPUT

    /* -------- System Start Message -------- */
    UARTTxStr("\r\nTIME-STAMPED SENSOR LOGGER STARTED\r\n");

    /* -------- Main Loop -------- */
    while (1)
    {
        temperature = Read_LM35('C');  // Read temperature in Celsius

        Display_Data(temperature);     // Display temperature & time on LCD

        temp_alert(temperature);       // Check if temperature exceeds set point

        edit_mode();                   // Check and handle edit mode input
    }
}
