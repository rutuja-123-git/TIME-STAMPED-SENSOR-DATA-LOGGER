#include <LPC21xx.H>      // LPC21xx register definitions
#include "rtc_defines.h"  // RTC control and configuration macros
#include "types.h"        // Custom data types (u32, s32, etc.)
#include "lcd.h"          // LCD function declarations


/*---------------------------------------------------------
   Array to store names of days of the week
   Index Mapping:
   0 ? Sunday
   1 ? Monday
   2 ? Tuesday
   3 ? Wednesday
   4 ? Thursday
   5 ? Friday
   6 ? Saturday
----------------------------------------------------------*/
char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};


/*---------------------------------------------------------
   RTC_Init()
   Purpose  : Initialize Real-Time Clock
   Steps    :
      1. Reset RTC
      2. Configure prescaler (if required)
      3. Enable RTC
----------------------------------------------------------*/
void RTC_Init(void) 
{
    CCR = RTC_RESET;   // Reset RTC

#ifdef _LPC2148
    // For LPC2148: Enable RTC & select clock source
    CCR = RTC_ENABLE | RTC_CLKSRC;  
#else
    // For LPC21xx: Configure prescaler values
    PREINT  = PREINT_VAL;   // Prescaler Integer
    PREFRAC = PREFRAC_VAL;  // Prescaler Fraction

    CCR = RTC_ENABLE;       // Enable RTC
#endif
}


/*---------------------------------------------------------
   GetRTCTimeInfo()
   Purpose : Read current time from RTC registers
----------------------------------------------------------*/
void GetRTCTimeInfo(s32 *hour, s32 *minute, s32 *second)
{
    *hour   = HOUR;   // Read hour register
    *minute = MIN;    // Read minute register
    *second = SEC;    // Read second register
}


/*---------------------------------------------------------
   DisplayRTCTime()
   Purpose : Display time in HH:MM:SS format on LCD
----------------------------------------------------------*/
void DisplayRTCTime(u32 hour, u32 minute, u32 second)
{
    CmdLCD(0x80);   // Move cursor to first row

    CharLCD((hour/10) + '0');
    CharLCD((hour%10) + '0');
    CharLCD(':');

    CharLCD((minute/10) + '0');
    CharLCD((minute%10) + '0');
    CharLCD(':');

    CharLCD((second/10) + '0');
    CharLCD((second%10) + '0');
}


/*---------------------------------------------------------
   GetRTCDateInfo()
   Purpose : Read current date from RTC registers
----------------------------------------------------------*/
void GetRTCDateInfo(s32 *date, s32 *month, s32 *year)
{
    *date  = DOM;     // Day of Month
    *month = MONTH;   // Month
    *year  = YEAR;    // Year
}


/*---------------------------------------------------------
   DisplayRTCDate()
   Purpose : Display date in DD/MM/YYYY format on LCD
----------------------------------------------------------*/
void DisplayRTCDate(u32 date, u32 month, u32 year)
{
    CmdLCD(0xC0);   // Move cursor to second row

    CharLCD((date/10) + '0');
    CharLCD((date%10) + '0');
    CharLCD('/');

    CharLCD((month/10) + '0');
    CharLCD((month%10) + '0');
    CharLCD('/');

    IntLCD(year);   // Display full year
}


/*---------------------------------------------------------
   SetRTCTimeInfo()
   Purpose : Set RTC time registers
----------------------------------------------------------*/
void SetRTCTimeInfo(u32 hour, u32 minute, u32 second)
{
    HOUR = hour;
    MIN  = minute;
    SEC  = second;
}


/*---------------------------------------------------------
   SetRTCDateInfo()
   Purpose : Set RTC date registers
----------------------------------------------------------*/
void SetRTCDateInfo(u32 date, u32 month, u32 year)
{
    DOM   = date;
    MONTH = month;
    YEAR  = year;	
}


/*---------------------------------------------------------
   GetRTCDay()
   Purpose : Read Day of Week from RTC
----------------------------------------------------------*/
void GetRTCDay(s32 *day)
{
    *day = DOW;   // Read Day Of Week register
}


/*---------------------------------------------------------
   DisplayRTCDay()
   Purpose : Display Day name (SUN�SAT) on LCD
----------------------------------------------------------*/
void DisplayRTCDay(u32 dow)
{
    CmdLCD(0x8A);        // Position cursor
    StrLCD(week[dow]);   // Display day string
}


/*---------------------------------------------------------
   SetRTCDay()
   Purpose : Set Day of Week register
----------------------------------------------------------*/
void SetRTCDay(u32 day)
{
    DOW = day;
}
