#ifndef RTC_H
#define RTC_H

/*---------------------------------------------------------
   RTC Header File
   Description : Function declarations for RTC module
----------------------------------------------------------*/

#include "types.h"   // Custom data types (u32, s32, etc.)

/*---------------------------------------------------------
   RTC Initialization
----------------------------------------------------------*/

/* Initialize Real-Time Clock */
void RTC_Init(void);


/*---------------------------------------------------------
   RTC Time Functions
----------------------------------------------------------*/

/* 
   Get current RTC time
   Parameters:
      hour   ? Pointer to store hour (0�23)
      minute ? Pointer to store minute (0�59)
      second ? Pointer to store second (0�59)
*/
void GetRTCTimeInfo(s32 *, s32 *, s32 *);

/*
   Display RTC time on LCD
   Format: HH:MM:SS
*/
void DisplayRTCTime(u32, u32, u32);

/*
   Set RTC time
   Parameters:
      hour   ? 0�23
      minute ? 0�59
      second ? 0�59
*/
void SetRTCTimeInfo(u32, u32, u32);


/*---------------------------------------------------------
   RTC Date Functions
----------------------------------------------------------*/

/*
   Get current RTC date
   Parameters:
      date  ? Pointer to store day (1�31)
      month ? Pointer to store month (1�12)
      year  ? Pointer to store year (YYYY)
*/
void GetRTCDateInfo(s32 *, s32 *, s32 *);

/*
   Display RTC date on LCD
   Format: DD/MM/YYYY
*/
void DisplayRTCDate(u32, u32, u32);

/*
   Set RTC date
   Parameters:
      date  ? 1�31
      month ? 1�12
      year  ? Four-digit year
*/
void SetRTCDateInfo(u32, u32, u32);


/*---------------------------------------------------------
   RTC Day Functions
----------------------------------------------------------*/

/*
   Get Day of Week
   0 ? Sunday
   1 ? Monday
   ...
   6 ? Saturday
*/
void GetRTCDay(s32 *);

/*
   Display Day of Week on LCD
*/
void DisplayRTCDay(u32);

/*
   Set Day of Week
   0 ? Sunday to 6 ? Saturday
*/
void SetRTCDay(u32);


#endif   // End of RTC_H

