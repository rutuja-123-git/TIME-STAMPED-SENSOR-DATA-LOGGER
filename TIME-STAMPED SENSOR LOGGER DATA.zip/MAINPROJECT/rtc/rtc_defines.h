#ifndef RTC_DEFINES_H
#define RTC_DEFINES_H

/*---------------------------------------------------------
   System Clock Configuration Macros
----------------------------------------------------------*/

/* Main Oscillator Frequency (12 MHz crystal) */
#define FOSC 12000000

/* CPU Clock (CCLK)
   CCLK = 5 � FOSC
   ? 5 � 12 MHz = 60 MHz
*/
#define CCLK (5 * FOSC)

/* Peripheral Clock (PCLK)
   PCLK = CCLK / 4
   ? 60 MHz / 4 = 15 MHz
*/
#define PCLK (CCLK / 4)


/*---------------------------------------------------------
   RTC Prescaler Calculation
   RTC requires 32.768 kHz clock for 1-second increment
----------------------------------------------------------*/

/* Prescaler Integer Value
   Formula: (PCLK / 32768) - 1
*/
#define PREINT_VAL ((PCLK / 32768) - 1)

/* Prescaler Fractional Value
   Formula: PCLK - (PREINT_VAL + 1) � 32768
*/
#define PREFRAC_VAL (PCLK - (PREINT_VAL + 1) * 32768)


/*---------------------------------------------------------
   RTC CCR (Clock Control Register) Bit Definitions
----------------------------------------------------------*/

/* Enable RTC (Bit 0) */
#define RTC_ENABLE  (1 << 0)

/* Reset RTC (Bit 1) */
#define RTC_RESET   (1 << 1)

/* Select Clock Source (Bit 4)
   Used mainly in LPC2148
*/
#define RTC_CLKSRC  (1 << 4)


/*---------------------------------------------------------
   Uncomment below if using LPC2148
----------------------------------------------------------*/
// #define _LPC2148


#endif   // End of RTC_DEFINES_H
