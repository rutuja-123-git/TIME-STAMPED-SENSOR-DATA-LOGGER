/*---------------------------------------------------------
   Custom Data Type Definitions
   Description : User-defined data types for portability
                 and readability in embedded systems.
----------------------------------------------------------*/

/* 8-bit unsigned integer (0 to 255) */
typedef unsigned char u8;

/* 8-bit signed integer (-128 to +127) */
typedef signed char s8;

/* 16-bit unsigned integer (0 to 65535) */
typedef unsigned short int u16;

/* 16-bit signed integer (-32768 to +32767) */
typedef signed short int s16;

/* 32-bit unsigned integer (0 to 4,294,967,295) */
typedef unsigned int u32;

/* 32-bit signed integer (-2,147,483,648 to +2,147,483,647) */
typedef signed int s32;

/* 32-bit floating-point number (IEEE 754 format) */
typedef float f32;


