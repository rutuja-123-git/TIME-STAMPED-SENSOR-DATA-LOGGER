#include <LPC21xx.h>     // LPC21xx register definitions
#include "defines.h"     // Macro definitions (READBIT etc.)
#include "PinConnect.h"  // Pin configuration utilities (optional)
#include "types.h"       // Custom data types (u8, s8, u32, f32)

/*---------------------------------------------------------
   Function Name : InitUART
   Description   : Initializes UART0 for serial communication.
                   Configured for:
                   - 9600 baud rate
                   - 8 data bits
                   - 1 stop bit
                   - No parity
----------------------------------------------------------*/
void InitUART(void)
{
    /* Configure P0.0 as TXD0 and P0.1 as RXD0 */
    PINSEL0 |= 0x00000005;  
    // Alternative method:
    // CfgPinFunc(0,0,1);  // P0.0 ? TXD0
    // CfgPinFunc(0,1,1);  // P0.1 ? RXD0

    U0LCR = 0x03;        // 8-bit word length, 1 stop bit, no parity
    U0LCR |= 1 << 7;     // Enable DLAB (Divisor Latch Access Bit)

    U0DLL = 97;          // Baud rate low byte (for 9600 @ 15MHz PCLK)
    U0DLM = 0;           // Baud rate high byte

    U0LCR &= ~(1 << 7);  // Disable DLAB
}


/*---------------------------------------------------------
   Function Name : UARTRxChar
   Description   : Receives a single character from UART0.
   Return        : Received character
----------------------------------------------------------*/
s8 UARTRxChar(void)
{
    while(!READBIT(U0LSR,0));   // Wait until data ready
    return (U0RBR);             // Return received character
}


/*---------------------------------------------------------
   Function Name : UARTTxChar
   Description   : Transmits a single character via UART0.
   Parameter     : ch ? Character to transmit
----------------------------------------------------------*/
void UARTTxChar(s8 ch)
{
    U0THR = ch;                 // Load character into transmit register
    while(!READBIT(U0LSR,6));   // Wait until transmission complete
}


/*---------------------------------------------------------
   Function Name : UARTTxStr
   Description   : Transmits a null-terminated string.
   Parameter     : ptr ? Pointer to string
----------------------------------------------------------*/
void UARTTxStr(s8 *ptr)
{
    while(*ptr)                 // Loop until NULL character
        UARTTxChar(*ptr++);     // Transmit each character
}


/*---------------------------------------------------------
   Function Name : UARTTxu32
   Description   : Transmits unsigned 32-bit integer.
                   Converts number to ASCII manually.
   Parameter     : num ? Unsigned integer value
----------------------------------------------------------*/
void UARTTxu32(u32 num)
{
    u8 a[10];       // Array to store digits
    s8 i = 0;

    if(num == 0)
    {
        UARTTxChar('0');
    }
    else
    {
        /* Convert number into digits (reverse order) */
        while(num > 0)
        {
            a[i++] = num % 10 + 48;  // Convert to ASCII
            num = num / 10;
        }

        /* Transmit digits in correct order */
        for(--i; i >= 0; i--)
            UARTTxChar(a[i]);
    }
}


/*---------------------------------------------------------
   Function Name : UARTTxF32
   Description   : Transmits floating point number.
                   Prints up to 6 digits after decimal.
   Parameter     : fnum ? Floating point number
----------------------------------------------------------*/
void UARTTxf32(f32 fnum)
{
    u32 num, i;

    /* Handle negative numbers */
    if(fnum < 0)
    {
        UARTTxChar('-');
        fnum = -fnum;
    }

    num = fnum;           // Integer part
    UARTTxu32(num);       // Transmit integer part
    UARTTxChar('.');      // Decimal point

    /* Transmit 6 digits after decimal */
    for(i = 0; i < 6; i++)
    {
        fnum = (fnum - num) * 10;
        num = fnum;
        UARTTxChar(num + 48);
    }
}
