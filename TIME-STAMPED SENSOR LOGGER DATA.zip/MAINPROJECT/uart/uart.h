#include "types.h"   // Custom data type definitions (u8, s8, u32, f32)

/*---------------------------------------------------------
   UART Function Prototypes
   Description : Declarations of UART driver functions
----------------------------------------------------------*/

/*---------------------------------------------------------
   Function Name : InitUART
   Description   : Initializes UART0 for serial communication
                   (baud rate, word length, stop bits etc.)
   Parameters    : None
   Return Type   : void
----------------------------------------------------------*/
void InitUART(void);


/*---------------------------------------------------------
   Function Name : UARTTxChar
   Description   : Transmits a single character through UART
   Parameter     : u8 ? Character to transmit
   Return Type   : void
----------------------------------------------------------*/
void UARTTxChar(u8);


/*---------------------------------------------------------
   Function Name : UARTTxStr
   Description   : Transmits a null-terminated string
                   through UART
   Parameter     : s8* ? Pointer to string
   Return Type   : void
----------------------------------------------------------*/
void UARTTxStr(s8 *);


/*---------------------------------------------------------
   Function Name : UARTRxChar
   Description   : Receives a single character from UART
   Parameters    : None
   Return Type   : s8 ? Received character
----------------------------------------------------------*/
s8 UARTRxChar(void);


/*---------------------------------------------------------
   Function Name : UARTTxf32
   Description   : Transmits a floating-point number
                   through UART
   Parameter     : f32 ? Floating-point value
   Return Type   : void
----------------------------------------------------------*/
void UARTTxf32(f32 fnum);


/*---------------------------------------------------------
   Function Name : UARTTxu32
   Description   : Transmits an unsigned 32-bit integer
                   through UART
   Parameter     : u32 ? Unsigned integer value
   Return Type   : void
----------------------------------------------------------*/
void UARTTxu32(u32 num);
